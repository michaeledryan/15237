# About CMU Marauder's Map, 15-237 Unit Project
Mike Ryan, mer1 & Dian Xiao, dxiao

## Description
CMU Marauder's Map is an application where users can post events by specifying on a campus map where their event will be held. We have enclosed a sample listings.txt that contains several event to give you an idea what a populated view looks like. We are using webfonts from typekit so an internet connection is needed for ideal viewing experience.

#### Usage: Adding
Expand the add listing selection. Fill the add listing form and click 'Add to the map!' which will allow you to place a pin on the map. Once you click on the map you event will added. 

#### Usage: Viewing
If you click on placed pins on the map, the side listings panel will display more information about the event. Beneath the map, events are displayed in a list. The Filter By box below the map gives you functionality to pare down the list.

#### Usage: Deleting
To delete an event, click the "delete this listing" button in the main listings display. This will delete the listing from the server.